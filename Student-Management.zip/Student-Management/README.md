# Student Management System

## 📌 Project Overview

The Student Management System is a Salesforce-based application designed to manage student records, track subject-wise marks, calculate total scores automatically, and assign grades based on performance.

The system automates record creation, grading, and reporting to reduce manual effort and improve accuracy.

---

## 🎯 Business Problem

Educational institutions require a centralized system to:

- Maintain student records
- Track marks for multiple subjects
- Automatically calculate total marks
- Assign grades based on performance
- Generate academic performance reports

Manual tracking can lead to errors, duplication, and lack of visibility.

---

## 💡 Solution

Built a custom Salesforce application using:

- Custom Objects
- Master-Detail Relationship
- Roll-Up Summary Fields
- Formula Fields
- Record-Triggered Flow
- Validation Rules
- Reports & Dashboards

---

## 🏗 Data Model

### 1️⃣ Student__c

Stores student details.

Fields:
- Student Name
- Email
- Phone
- Batch
- Total Marks Obtained (Roll-Up Summary)
- Grade (Formula Field)

---

### 2️⃣ Marks__c

Child object related to Student.

Fields:
- Student (Master-Detail Relationship)
- Subject (Quiz, Assignment, Project, Final, Viva)
- Total Marks
- Marks Obtained

Relationship:
Marks__c → Master-Detail → Student__c

This relationship enables automatic roll-up calculation.

---

## 🔄 Automation Implemented

### 1️⃣ Record-Triggered Flow

Trigger:
- Runs when a new Student record is created.

Actions:
- Automatically creates 5 related Marks records:
  - Quiz
  - Assignment
  - Project
  - Final
  - Viva

Purpose:
Eliminates manual creation of subject records.

---

### 2️⃣ Roll-Up Summary Field

Automatically calculates:

Total Marks Obtained = SUM(Marks Obtained)

Ensures real-time calculation when marks are updated.

---

### 3️⃣ Formula Field (Grade Calculation)

Automatically assigns grade based on total marks:

- A (≥ 90)
- B (≥ 75)
- C (≥ 60)
- Fail (< 60)

This ensures consistent grading logic.

---

### 4️⃣ Validation Rule

- Marks Obtained cannot exceed Total Marks.
- Ensures data integrity.

---

## 📊 Reports & Dashboard

Created reports to track:

- Students by Grade
- Total Marks by Batch
- Subject-wise Performance

Dashboard Components:

- Pie Chart – Grade Distribution
- Bar Chart – Marks by Batch
- KPI – Total Students

---

## ⚙ Technical Features Used

- Custom Objects
- Master-Detail Relationship
- Roll-Up Summary Fields
- Formula Fields
- Record-Triggered Flow
- Validation Rules
- Reports & Dashboards
- Schema Builder (Data Modeling)

---

## 🧠 Design Decisions

- Used Master-Detail Relationship to enable Roll-Up Summary functionality.
- Used Record-Triggered Flow to automate subject record creation.
- Used Formula Field instead of manual grading for accuracy.
- Implemented validation rules to prevent incorrect data entry.

---

## 📸 Screenshots

Refer to `/Screenshots` folder for:

- Object Structure
- Master-Detail Relationship
- Schema Builder Diagram
- Roll-Up Summary Setup
- Grade Formula Setup
- Flow Automation Canvas
- Validation Rule
- Reports
- Dashboard
- Sample Working Record

---

## 🚀 Outcome

The system:

- Eliminates manual subject creation
- Automates grading process
- Ensures accurate total calculation
- Improves academic performance visibility
- Demonstrates strong Salesforce data modeling and automation skills

---

## 👩‍💻 Author

Anki  
Salesforce Administrator | CRM Automation Enthusiast
