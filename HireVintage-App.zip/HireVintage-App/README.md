# Recruitment Management Application

## 📌 Project Overview

The Recruitment Management Application is a custom Salesforce app designed to streamline the hiring process by managing Candidates, Job Positions, and Applications with automation and reporting.

This system helps HR teams efficiently track candidate progress from application to selection.

---

## 🎯 Business Problem

Organizations struggle to:
- Track multiple candidates for multiple job positions
- Avoid duplicate applications
- Automatically update candidate status
- Notify HR when a candidate is selected
- Generate recruitment performance reports

---

## 💡 Solution

Built a custom Salesforce application using:
- Custom Objects
- Junction Object (Many-to-Many Relationship)
- Record-Triggered Flow
- Validation Rules
- Email Notifications
- Reports & Dashboards

---

## 🏗 Data Model

### 1️⃣ Candidate__c
Stores applicant details.
- Name
- Email
- Phone
- Experience
- Status

### 2️⃣ Job__c
Stores job posting details.
- Job Title
- Department
- Location
- Open Positions
- Status

### 3️⃣ Application__c (Junction Object)
Connects Candidate and Job (Many-to-Many Relationship).
- Candidate (Master-Detail)
- Job (Master-Detail)
- Application Status (Applied, Interviewed, Selected, Rejected)
- Interview Date

---

## 🔄 Automation Implemented

### 1️⃣ Record-Triggered Flow
- Triggered when Application Status = "Selected"
- Automatically updates Candidate Status to "Hired"
- Sends email notification to HR

### 2️⃣ Validation Rule
Prevents duplicate applications:
- A candidate cannot apply for the same job twice.

---

## 📊 Reports & Dashboard

Created reports to track:
- Applications by Status
- Selected vs Rejected Candidates
- Job-wise Application Count

Dashboard Components:
- Pie Chart – Application Status Distribution
- Bar Chart – Job-wise Applications
- KPI – Total Selected Candidates

---

## ⚙ Technical Features Used

- Custom Objects
- Master-Detail Relationships
- Junction Object Design
- Record-Triggered Flow
- Email Alerts
- Validation Rules
- Reports & Dashboards

---

## 🧠 Design Decisions

- Used a Junction Object to handle Many-to-Many relationship between Candidate and Job.
- Used Master-Detail relationship to maintain data integrity.
- Used Flow instead of Process Builder (modern Salesforce best practice).
- Implemented validation rule to ensure data accuracy.

---

## 📸 Screenshots

See `/Screenshots` folder for:
- Object Structure
- Flow Automation
- Validation Rule
- Dashboard
- Sample Records

---

## 🚀 Outcome

The application:
- Automates recruitment workflow
- Reduces manual tracking effort
- Improves hiring visibility
- Prevents duplicate applications
- Provides real-time hiring analytics

---

## 👩‍💻 Author

Anki  
Salesforce Administrator | CRM Automation Enthusiast
